window.AttendanceMock = (() => {
  const months = ["202606", "202605", "202604"];
  const monthLabels = {
    "202606": "2026-06",
    "202605": "2026-05",
    "202604": "2026-04",
  };

  const employees = [
    { id: "YK044298", name: "朱方安", avatar: "朱", level: "P4", department: "后端开发部", center: "公共支持中心", position: "Golang开发", employment: "正式", joinedAt: "2020-08-15", hrbp: "王芳", manager: "张大卫", location: "滨江" },
    { id: "YK500003", name: "刘备", avatar: "刘", level: "M3", department: "技术研发部", center: "产品研发中心", position: "技术负责人", employment: "正式", joinedAt: "2018-03-18", hrbp: "王芳", manager: "孙浩", location: "创智天地" },
    { id: "YK045440", name: "王建国", avatar: "王", level: "M4", department: "游戏研发部", center: "产品研发中心", position: "项目负责人", employment: "正式", joinedAt: "2019-11-09", hrbp: "王芳", manager: "李强", location: "创智天地" },
    { id: "YK042587", name: "张卫", avatar: "张", level: "T4", department: "后端开发部", center: "公共支持中心", position: "服务端开发", employment: "正式", joinedAt: "2021-05-20", hrbp: "王芳", manager: "孙浩", location: "滨江" },
    { id: "YK202601", name: "陈静", avatar: "陈", level: "P3", department: "运营支持部", center: "市场中心", position: "运营支持", employment: "正式", joinedAt: "2022-06-10", hrbp: "张梅", manager: "周强", location: "北杨" },
    { id: "YK202603", name: "李娜", avatar: "李", level: "P4", department: "市场营销部", center: "市场中心", position: "市场策划", employment: "正式", joinedAt: "2021-09-01", hrbp: "张梅", manager: "吴晓", location: "北杨" },
    { id: "WB000136", name: "小新", avatar: "新", level: "W5", department: "人力资源部", center: "管理中心", position: "HR 系统支持", employment: "人力外包", joinedAt: "2025-10-21", hrbp: "钱燕", manager: "甄嬛", location: "滨江" },
    { id: "WB000228", name: "赵阳", avatar: "赵", level: "W4", department: "技术研发部", center: "产品研发中心", position: "测试支持", employment: "人力外包", joinedAt: "2024-04-12", hrbp: "王芳", manager: "孙浩", location: "广州" },
    { id: "WB000317", name: "吴东", avatar: "吴", level: "W3", department: "美术设计部", center: "产品研发中心", position: "外包美术", employment: "人力外包", joinedAt: "2023-12-01", hrbp: "王芳", manager: "林秀", location: "创智天地" },
  ];

  const metrics = {
    active: 2148,
    required: 2031,
    actual: 1889,
    coverage: 93.0,
    abnormal: 142,
    abnormalRate: 6.6,
    avgHour: 8.74,
    statDate: "2026-06-30",
  };

  const abnormalEmployees = [
    { employeeId: "YK042587", name: "张卫", department: "技术研发部", total: 12, late: 7, early: 3, missing: 2, absenteeism: 1 },
    { employeeId: "YK202603", name: "李娜", department: "市场营销部", total: 10, late: 5, early: 4, missing: 1, absenteeism: 0 },
    { employeeId: "YK045440", name: "王建国", department: "产品设计部", total: 9, late: 6, early: 2, missing: 1, absenteeism: 0 },
    { employeeId: "YK202601", name: "陈静", department: "运营支持部", total: 8, late: 4, early: 3, missing: 1, absenteeism: 1 },
    { employeeId: "WB000228", name: "赵阳", department: "技术研发部", total: 7, late: 5, early: 1, missing: 1, absenteeism: 0 },
    { employeeId: "WB000317", name: "吴东", department: "美术设计部", total: 7, late: 3, early: 2, missing: 2, absenteeism: 0 },
    { employeeId: "YK044298", name: "朱方安", department: "后端开发部", total: 6, late: 2, early: 1, missing: 3, absenteeism: 0 },
    { employeeId: "WB000136", name: "小新", department: "人力资源部", total: 6, late: 4, early: 1, missing: 1, absenteeism: 0 },
  ];

  const trend = [
    { month: "1月", employee: 8.9, manager: 9.6, outsource: 8.2, employeeMom: 1.1, managerMom: 1.1, outsourceMom: 1.2 },
    { month: "2月", employee: 8.5, manager: 9.2, outsource: 8.0, employeeMom: -4.5, managerMom: -4.2, outsourceMom: -2.4 },
    { month: "3月", employee: 9.1, manager: 9.8, outsource: 8.3, employeeMom: 7.1, managerMom: 6.5, outsourceMom: 3.8 },
    { month: "4月", employee: 9.3, manager: 9.9, outsource: 8.4, employeeMom: 2.2, managerMom: 1.0, outsourceMom: 1.2 },
    { month: "5月", employee: 9.2, manager: 10.0, outsource: 8.5, employeeMom: -1.1, managerMom: 1.0, outsourceMom: 1.2 },
    { month: "6月", employee: 9.5, manager: 10.2, outsource: 8.6, employeeMom: 3.3, managerMom: 2.0, outsourceMom: 1.2 },
    { month: "7月", employee: 9.7, manager: 10.4, outsource: 8.7, employeeMom: 2.1, managerMom: 2.0, outsourceMom: 1.2 },
    { month: "8月", employee: 9.6, manager: 10.3, outsource: 8.6, employeeMom: -1.0, managerMom: -1.0, outsourceMom: -1.1 },
    { month: "9月", employee: 9.4, manager: 10.1, outsource: 8.4, employeeMom: -2.1, managerMom: -1.9, outsourceMom: -2.3 },
    { month: "10月", employee: 8.8, manager: 9.5, outsource: 8.1, employeeMom: -6.4, managerMom: -5.9, outsourceMom: -3.6 },
    { month: "11月", employee: 9.3, manager: 9.9, outsource: 8.3, employeeMom: 5.7, managerMom: 4.2, outsourceMom: 2.5 },
    { month: "12月", employee: 9.0, manager: 9.7, outsource: 8.2, employeeMom: -3.2, managerMom: -2.0, outsourceMom: -1.2 },
  ];

  const departments = ["后端开发部", "海外运营部", "游戏研发部", "前端开发部", "产品规划部", "测试质量部", "市场公关部", "美术设计部", "数据分析部", "公共支持中心"];
  const managers = ["张大卫", "李强", "王建国", "周涛", "林秀", "何冰", "陈晨", "吴东", "黄磊", "王芳"];

  const departmentRankTop = departments.map((department, index) => ({
    rank: index + 1,
    department,
    count: [45, 28, 32, 38, 22, 30, 18, 25, 15, 50][index],
    manager: managers[index],
    hrbp: ["王芳", "王芳", "王芳", "王芳", "张梅", "王芳", "张梅", "王芳", "刘佳", "钱燕"][index],
    avgHour: [10.2, 9.8, 9.6, 9.3, 9.1, 8.9, 8.6, 8.5, 8.4, 8.1][index],
    lastHour: [9.3, 9.3, 9.1, 9.0, 9.2, 8.7, 8.5, 8.6, 8.2, 8.3][index],
    lastRank: index + 2,
  }));
  const departmentRankBottom = [...departmentRankTop].reverse().map((item, index) => ({ ...item, rank: index + 1, avgHour: +(7.2 + index * 0.16).toFixed(1), lastHour: +(7.5 + index * 0.12).toFixed(1) }));
  const managerRankTop = managers.map((name, index) => ({
    rank: index + 1,
    name,
    level: ["T4", "M3", "M4", "T3", "P4", "T3", "M2", "D4", "P3", "M3"][index],
    department: departments[index],
    hrbp: ["王芳", "王芳", "王芳", "王芳", "张梅", "王芳", "张梅", "王芳", "刘佳", "钱燕"][index],
    avgHour: [10.5, 10.1, 9.9, 9.7, 9.4, 9.2, 9.0, 8.8, 8.7, 8.5][index],
    lastHour: [9.7, 9.5, 9.6, 9.4, 9.5, 8.9, 8.8, 8.9, 8.5, 8.7][index],
    lastRank: index + 2,
    employeeId: employees[index % employees.length].id,
  }));
  const managerRankBottom = [...managerRankTop].reverse().map((item, index) => ({ ...item, rank: index + 1, avgHour: +(7.0 + index * 0.18).toFixed(1), lastHour: +(7.4 + index * 0.1).toFixed(1) }));

  function monthValue(seed, monthIndex, delta = 0) {
    return +(seed + monthIndex * 0.07 + delta).toFixed(2);
  }

  const formalReportRows = departments.slice(0, 6).map((department, index) => ({
    division: index < 3 ? "产品事业部" : "职能中心",
    center: ["产品研发中心", "产品研发中心", "市场中心", "销售中心", "财务中心", "人力资源中心"][index],
    department,
    manager: managers[index],
    hrbp: ["王芳", "王芳", "张梅", "张梅", "刘佳", "刘佳"][index],
    count: [40, 22, 25, 35, 15, 12][index],
    months: Object.fromEntries(months.map((m, mi) => [m, {
      companyHour: 8.92,
      count: [40, 22, 25, 35, 15, 12][index],
      avgHour: monthValue(9.21 - index * 0.08, mi),
      hourMom: +(0.3 + index * 0.25 - mi * 0.35).toFixed(1),
      rank: index + 1 + mi,
      companyAbnormal: 3.0,
      abnormalAvg: +(3.2 - index * 0.25 + mi * 0.18).toFixed(1),
      abnormalMom: +(8.6 + index * 0.9 - mi * 2.1).toFixed(1),
      abnormalRank: 7 + index,
      remark: index % 2 ? "关注漏卡补提" : "点击编辑...",
    }]))
  }));

  const outsourceReportRows = formalReportRows.map((row, index) => ({
    ...row,
    department: ["技术研发部", "美术设计部", "运营支持部", "测试质量部", "公共事务部", "人事行政部"][index],
    count: [12, 8, 10, 9, 6, 5][index],
    months: Object.fromEntries(months.map((m, mi) => [m, {
      companyHour: 8.36,
      count: [12, 8, 10, 9, 6, 5][index],
      avgHour: monthValue(8.48 - index * 0.06, mi),
      hourMom: +(1.2 - index * 0.2 - mi * 0.4).toFixed(1),
      rank: index + 2 + mi,
      companyAbnormal: 2.4,
      abnormalAvg: +(2.1 + index * 0.2 + mi * 0.1).toFixed(1),
      abnormalMom: +(6.0 - index * 0.7 - mi).toFixed(1),
      abnormalRank: 4 + index,
      remark: "外包月度复核",
    }]))
  }));

  function peopleReportRows(scope) {
    const source = scope === "outsourcing" ? employees.filter(e => e.employment === "人力外包") : employees.filter(e => e.employment === "正式").slice(0, 6);
    return source.map((employee, index) => ({
      id: employee.id,
      name: employee.name,
      center: employee.center,
      department: employee.department,
      position: employee.position,
      joinedAt: employee.joinedAt,
      level: employee.level,
      hrbp: employee.hrbp,
      months: Object.fromEntries(months.map((m, mi) => [m, {
        groupHour: scope === "outsourcing" ? 8.36 : 8.92,
        avgHour: monthValue(scope === "outsourcing" ? 8.4 + index * 0.12 : 8.8 + index * 0.16, mi),
        hourMom: +(index * 0.7 - mi * 0.6 + 0.8).toFixed(1),
        rank: index + 1 + mi,
        groupAbnormal: scope === "outsourcing" ? 2.4 : 3.0,
        abnormalCount: Math.max(0, 5 - index + mi),
        abnormalMom: +(9.8 - index * 1.2 - mi * 2).toFixed(1),
        abnormalRank: index + 3 + mi,
      }]))
    }));
  }

  function outingRows(scope) {
    return (scope === "outsourcing" ? outsourceReportRows : formalReportRows).slice(0, 5).map((row, index) => ({
      center: row.center,
      department: row.department,
      manager: row.manager,
      hrbp: row.hrbp,
      count: row.count,
      months: Object.fromEntries(months.map((m, mi) => [m, {
        applicantCount: Math.max(1, 8 - index + mi),
        days: +(12.5 - index * 1.1 + mi * 0.5).toFixed(1),
        avgDays: +(1.6 - index * 0.08 + mi * 0.06).toFixed(2),
        rank: index + 1 + mi,
      }]))
    }));
  }

  const drawerRows = employees.map((employee, index) => ({
    ...employee,
    date: "2026-06-30",
    clockIn: index % 3 === 0 ? "10:15" : "09:28",
    clockOut: index % 2 ? "20:30" : "19:42",
    result: index % 3 === 0 ? "迟到" : index % 4 === 0 ? "漏打卡" : "正常",
    workHour: index % 4 === 0 ? "--" : `${(8.4 + index * 0.18).toFixed(1)}h`,
    leaveDays: index % 3 === 0 ? "0.5" : "0",
    remark: index % 3 === 0 ? "补卡流程待确认" : "当前筛选范围",
  }));

  const attendanceRecords = {
    YK044298: [
      { date: "2026-06-15（一）", dateType: "工作日", clockIn: "09:58", clockOut: "20:30", workHour: "9.5h", result: "正常", abnormal: "--", process: "--", remark: "-" },
      { date: "2026-06-14（日）", dateType: "休息日", clockIn: "--", clockOut: "--", workHour: "--", result: "休息日", abnormal: "--", process: "--", remark: "-" },
      { date: "2026-06-12（五）", dateType: "工作日", clockIn: "10:15", clockOut: "21:00", workHour: "9.7h", result: "迟到", abnormal: "迟到", process: "补卡审批", remark: "忘带手机" },
      { date: "2026-06-11（四）", dateType: "工作日", clockIn: "09:31", clockOut: "--", workHour: "--", result: "漏打卡", abnormal: "漏打卡", process: "补卡审批", remark: "下班漏卡" },
      { date: "2026-06-10（三）", dateType: "工作日", clockIn: "09:22", clockOut: "19:05", workHour: "8.7h", result: "正常", abnormal: "--", process: "--", remark: "-" },
    ],
  };

  return {
    months,
    monthLabels,
    employees,
    metrics,
    abnormalEmployees,
    trend,
    departmentRankTop,
    departmentRankBottom,
    managerRankTop,
    managerRankBottom,
    formalReportRows,
    outsourceReportRows,
    formalPeopleRows: peopleReportRows("formal"),
    outsourcePeopleRows: peopleReportRows("outsourcing"),
    formalOutingRows: outingRows("formal"),
    outsourceOutingRows: outingRows("outsourcing"),
    drawerRows,
    attendanceRecords,
  };
})();
