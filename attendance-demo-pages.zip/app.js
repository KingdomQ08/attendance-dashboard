const data = window.AttendanceMock;

const state = {
  mainTab: "overview",
  reportScope: "formal",
  reportType: "department",
  rankMode: { department: "top", manager: "top" },
  filters: {
    managementDepartment: "全部",
    keyword: "",
    employment: "全部",
    level: "全部",
    position: "全部",
    location: "全部",
    statScope: "标准口径",
    statusDemo: "正常",
    statDate: "2026-06-30",
    abnormalMonth: "202606",
    rankMonth: "202606",
    months: [...data.months],
    localDepartment: "",
  },
  employeeFilter: {
    month: "202606",
    start: "2026/05/16",
    end: "2026/06/15",
    abnormalType: "全部",
    statScope: "全口径",
    quickType: "全部",
  },
  drawer: null,
  toast: "",
  monthDropdownOpen: false,
  sidebarCollapsed: false,
  departmentPanelCollapsed: false,
};

const $app = document.querySelector("#app");

function cx(...parts) {
  return parts.filter(Boolean).join(" ");
}

function trendText(value) {
  if (value === null || value === undefined || value === "--") return `<span class="muted">--</span>`;
  const positive = Number(value) >= 0;
  return `<span class="${positive ? "trend-up" : "trend-down"}">${positive ? "↑" : "↓"} ${Math.abs(value).toFixed(1)}%</span>`;
}

function toast(message) {
  state.toast = message;
  render();
  window.clearTimeout(toast._timer);
  toast._timer = window.setTimeout(() => {
    state.toast = "";
    render();
  }, 1800);
}

function setRoute(hash) {
  window.location.hash = hash;
}

function getRoute() {
  return window.location.hash || "#/attendance/overview";
}

function employeeById(id) {
  return data.employees.find((employee) => employee.id === id) || data.employees[0];
}

function option(value, current, label = value) {
  return `<option value="${value}" ${value === current ? "selected" : ""}>${label}</option>`;
}

function employeeMatches(employee, scope = null) {
  const keyword = state.filters.keyword.trim().toLowerCase();
  const employmentFilter = state.mainTab === "reportFormal" ? "正式" : state.mainTab === "reportOutsource" ? "人力外包" : state.filters.employment;
  if (scope === "formal" && employee.employment !== "正式") return false;
  if (scope === "outsourcing" && employee.employment !== "人力外包") return false;
  if (employmentFilter !== "全部" && employee.employment !== employmentFilter) return false;
  if (state.filters.managementDepartment !== "全部" && employee.center !== state.filters.managementDepartment) return false;
  if (state.filters.level !== "全部" && employee.level !== state.filters.level) return false;
  if (state.filters.position !== "全部" && employee.position !== state.filters.position) return false;
  if (state.filters.location !== "全部" && employee.location !== state.filters.location) return false;
  if (state.filters.localDepartment && employee.department !== state.filters.localDepartment) return false;
  if (keyword && !`${employee.id} ${employee.name} ${employee.department} ${employee.center} ${employee.manager}`.toLowerCase().includes(keyword)) return false;
  return true;
}

function filteredEmployees(scope = null) {
  return data.employees.filter((employee) => employeeMatches(employee, scope));
}

function rowMatches(row) {
  const keyword = state.filters.keyword.trim().toLowerCase();
  if (state.filters.managementDepartment !== "全部" && row.center && row.center !== state.filters.managementDepartment) return false;
  if (state.filters.level !== "全部" && row.level && row.level !== state.filters.level) return false;
  if (state.filters.position !== "全部" && row.position && row.position !== state.filters.position) return false;
  if (state.filters.localDepartment && row.department !== state.filters.localDepartment) return false;
  if (keyword && !`${row.id || ""} ${row.name || ""} ${row.department || ""} ${row.center || ""} ${row.manager || ""}`.toLowerCase().includes(keyword)) return false;
  return true;
}

function ensureActionAllowed(label) {
  if (state.filters.statusDemo !== "无权限") return true;
  toast(`无权限：当前角色不能${label}`);
  return false;
}

function filteredDrawerRows() {
  const ids = new Set(filteredEmployees().map((employee) => employee.id));
  return data.drawerRows.filter((row) => ids.size ? ids.has(row.id) : employeeMatches(row));
}

function openDrawer(title, rows = filteredDrawerRows(), subtitle = "当前筛选条件下员工明细", kind = "attendance") {
  state.drawer = { title, subtitle, rows, kind };
  render();
}

function closeDrawer() {
  state.drawer = null;
  render();
}

function updateFilter(key, value) {
  state.filters[key] = value;
  if (key === "statusDemo") {
    window.setTimeout(render, 350);
  }
  render();
}

function renderShell(content) {
  const route = getRoute();
  const isEmployeePage = route.startsWith("#/employee/");
  const isAttendancePage = route.startsWith("#/attendance/");
  return `
    <div class="app-shell">
      <header class="topbar">
        <div class="brand"><span class="brand-mark">e</span><span>EHR</span></div>
        <nav class="topnav">
          <button>首页</button>
          <button class="active">人事</button>
          <button>OKR</button>
          <button>绩效</button>
        </nav>
        <div class="help">? 帮助文档</div>
        <div class="user"><span class="avatar-small">诸</span>诸葛亮1</div>
      </header>
      <div class="body">
        <aside class="sidebar ${state.sidebarCollapsed ? "collapsed" : ""}">
          <button class="sidebar-collapse" data-action="toggleSidebar" title="${state.sidebarCollapsed ? "展开菜单" : "收起菜单"}">${state.sidebarCollapsed ? "›" : "‹"}</button>
          <button class="side-item ${isAttendancePage ? "active" : ""}"><span class="side-icon">▥</span><span class="side-label">人事看板</span></button>
          <div class="side-sub board-sub"><span class="side-label">人员概览</span></div>
          <button class="side-sub board-sub ${isAttendancePage ? "active" : ""}" data-action="navAttendance"><span class="side-label">考勤看板</span></button>
          <div class="side-sub board-sub"><span class="side-label">组织视图</span></div>
          <button class="side-item ${isEmployeePage ? "active" : ""}"><span class="side-icon">♙</span><span class="side-label">人事管理</span></button>
          <button class="side-sub ${isEmployeePage ? "active" : ""}" data-action="navEmployee"><span class="side-label">在职员工</span></button>
          <div class="side-sub"><span class="side-label">离职员工</span></div>
          <div class="side-sub"><span class="side-label">试用期管理</span></div>
          <div class="side-sub"><span class="side-label">合同管理</span></div>
          <button class="side-item"><span class="side-icon">⌘</span><span class="side-label">组织管理</span></button>
          <button class="side-item"><span class="side-icon">☰</span><span class="side-label">系统配置</span></button>
        </aside>
        <main class="main">${content}</main>
      </div>
      ${state.drawer ? renderDrawer() : ""}
      ${state.toast ? `<div class="toast">${state.toast}</div>` : ""}
    </div>
  `;
}

function renderGlobalFilters() {
  return `
    <nav class="board-tabs">
      <button type="button">人员概览</button>
      <button type="button" class="active">考勤看板</button>
      <button type="button">组织视图</button>
    </nav>
  `;
}

function renderDashboardFilters() {
  const lockedEmployment = state.mainTab === "reportFormal" ? "正式" : state.mainTab === "reportOutsource" ? "人力外包" : state.filters.employment;
  return `
    <section class="filter-bar">
      <label class="control search"><span class="search-icon">⌕</span><input value="${state.filters.keyword}" data-action="filter" data-key="keyword" placeholder="姓名 / 工号" /></label>
      ${selectControl("用工性质", "employment", ["全部", "正式", "人力外包"], lockedEmployment, state.mainTab !== "overview")}
      ${selectControl("职级", "level", ["全部", "P3", "P4", "T4", "M3", "M4", "W5"])}
      ${selectControl("岗位", "position", ["全部", "Golang开发", "技术负责人", "项目负责人", "服务端开发", "市场策划", "测试支持", "外包美术"])}
      ${selectControl("工作地点", "location", ["全部", "滨江", "创智天地", "北杨", "广州"])}
      ${selectControl("统计口径", "statScope", ["标准口径", "全口径"])}
      <button class="clear-btn" data-action="clearFilters"><span class="clear-icon" aria-hidden="true"></span><span>清空</span></button>
    </section>
    <nav class="main-tabs">
      <button class="${state.mainTab === "overview" ? "active" : ""}" data-action="mainTab" data-tab="overview">考勤概览</button>
      <button class="${state.mainTab === "reportFormal" ? "active" : ""}" data-action="mainTab" data-tab="reportFormal">考勤报表（正式）</button>
      <button class="${state.mainTab === "reportOutsource" ? "active" : ""}" data-action="mainTab" data-tab="reportOutsource">考勤报表（人力外包）</button>
    </nav>
  `;
}

function selectControl(label, key, options, value = state.filters[key], disabled = false) {
  const scopeTip = key === "statScope" ? `<span class="filter-info-tip" data-tip="标准口径：按需求文档排除实习生、顾问、兼职、客服部、游戏运营部、司机岗、境外/非中国大陆工作地及无需打卡人员。全口径：在当前权限范围内展示全部可统计人员，用于排查和对账。">?</span>` : "";
  return `
    <label class="control select control-${key} ${disabled ? "disabled" : ""}">
      <span>${label}</span>
      <select data-action="filter" data-key="${key}" ${disabled ? "disabled" : ""}>
        ${options.map((option) => `<option value="${option}" ${option === value ? "selected" : ""}>${option}</option>`).join("")}
      </select>
      ${scopeTip}
    </label>
  `;
}

function renderDepartmentPanel() {
  const groups = [
    { name: "全部", count: "2651人", center: "全部", children: [] },
    { name: "产品事业部", count: "63人", center: "产品研发中心", children: [
      { name: "产品研发中心", count: "22人", center: "产品研发中心" },
      { name: "后端开发部", count: "7人", center: "公共支持中心", department: "后端开发部" },
      { name: "技术研发部", count: "8人", center: "产品研发中心", department: "技术研发部" },
      { name: "游戏研发部", count: "32人", center: "产品研发中心", department: "游戏研发部" },
      { name: "美术设计部", count: "25人", center: "产品研发中心", department: "美术设计部" },
    ] },
    { name: "商业化事业部", count: "41人", center: "市场中心", children: [
      { name: "市场营销部", count: "18人", center: "市场中心", department: "市场营销部" },
      { name: "运营支持部", count: "10人", center: "市场中心", department: "运营支持部" },
    ] },
    { name: "职能中心", count: "28人", center: "管理中心", children: [
      { name: "人力资源部", count: "6人", center: "管理中心", department: "人力资源部" },
      { name: "数据分析部", count: "15人", center: "管理中心", department: "数据分析部" },
    ] },
    { name: "公共支持中心", count: "29人", center: "公共支持中心", children: [
      { name: "公共事务部", count: "12人", center: "公共支持中心", department: "公共事务部" },
      { name: "测试质量部", count: "30人", center: "公共支持中心", department: "测试质量部" },
    ] },
  ];
  const isActive = (item) => {
    if (item.center === "全部") return state.filters.managementDepartment === "全部" && !state.filters.localDepartment;
    if (item.department) return state.filters.localDepartment === item.department;
    return state.filters.managementDepartment === item.center && !state.filters.localDepartment;
  };
  if (state.departmentPanelCollapsed) {
    return `
      <aside class="department-panel collapsed">
        <button class="department-toggle" data-action="toggleDepartmentPanel" title="展开管理部门">›</button>
        <span>管理部门</span>
      </aside>
    `;
  }
  return `
    <aside class="department-panel">
      <div class="department-title">
        <span>管理部门</span>
        <button class="department-toggle" data-action="toggleDepartmentPanel" title="收起管理部门">‹</button>
      </div>
      <label class="department-search"><span class="search-icon"></span><input placeholder="搜索部门" /></label>
      <div class="department-tree">
        ${groups.map((group) => `
          <button class="department-node level-0 ${isActive(group) ? "active" : ""}" data-action="departmentPanelFilter" data-center="${group.center}">
            <span>${group.children.length ? "⌄" : ""} ${group.name}</span><em>${group.count}</em>
          </button>
          ${group.children.map((child) => `
            <button class="department-node level-1 ${isActive(child) ? "active" : ""}" data-action="departmentPanelFilter" data-center="${child.center}" data-department="${child.department || ""}">
              <span>${child.name}</span><em>${child.count}</em>
            </button>
          `).join("")}
        `).join("")}
      </div>
    </aside>
  `;
}

function renderAttendanceDashboard() {
  const tabContent = state.mainTab === "overview" ? renderOverview() : renderReport(state.mainTab === "reportOutsource" ? "outsourcing" : "formal");
  return `
    <div class="dashboard-layout ${state.departmentPanelCollapsed ? "department-collapsed" : ""}">
      ${renderDepartmentPanel()}
      <div class="dashboard-main">
        ${renderGlobalFilters()}
        ${renderDashboardFilters()}
        <div class="content-scroll">
          ${state.filters.localDepartment ? `<div class="local-filter">局部筛选：部门 = ${state.filters.localDepartment}<button data-action="removeLocalFilter">移除</button></div>` : ""}
          ${renderScopeNotice()}
          ${tabContent}
        </div>
      </div>
    </div>
  `;
}

function renderScopeNotice() {
  return `<div class="notice dashboard-notice"><span class="notice-icon">!</span><span>考勤数据仅统计正式员工和人力外包；不含实习生、顾问、兼职、客服部、游戏运营部、司机岗、境外/非中国大陆工作地及无需打卡人员。法定节假日不纳入考勤分析。</span></div>`;
}

function renderOverview() {
  if (state.filters.statusDemo === "无权限") return renderStateCard("无权限", "当前角色未配置考勤概览查看权限。");
  if (state.filters.statusDemo === "数据失败") return renderStateCard("数据失败", "考勤系统数据生成失败，请稍后重试或联系管理员。", true);
  const abnormalRows = getAbnormalRows();
  return `
    <section class="panel metrics-panel">
      <div class="section-head">
        <div>
          <h2>考勤指标</h2>
          <span class="hint">点击卡片查看员工明细</span>
        </div>
        <label class="date-control">统计日 <input type="date" value="${state.filters.statDate}" data-action="filter" data-key="statDate" /></label>
      </div>
      ${state.filters.statusDemo === "loading" ? renderSkeletonCards(7) : state.filters.statusDemo === "empty" ? renderStateInline("暂无考勤指标数据") : renderMetricCards()}
    </section>
    <section class="panel">
      <div class="section-head">
        <h2>员工异常关注（${abnormalRows.length}人）</h2>
        <div class="section-actions">
          <label class="date-control">考勤月
            <select data-action="filter" data-key="abnormalMonth">
              ${data.months.map((month) => option(month, state.filters.abnormalMonth, month)).join("")}
            </select>
          </label>
          <span class="threshold">阈值 ≥ 6次</span>
        </div>
      </div>
      ${renderAbnormalEmployees(abnormalRows)}
    </section>
    <section class="panel chart-panel">
      <div class="section-head">
        <div>
          <h2>月平均工时趋势</h2>
          <p>叠面积折线图固定展示 1-12 月；点击节点拉起员工月度明细。</p>
        </div>
        <label class="control select compact"><span>月份范围</span><select><option>2026年 1月 - 12月</option></select></label>
      </div>
      ${renderTrendChart()}
    </section>
    <section class="table-card">${renderTrendTable()}</section>
    <section class="rank-grid">
      ${renderRanking("department", "top")}
      ${renderRanking("department", "bottom")}
      ${renderRanking("manager", "top")}
      ${renderRanking("manager", "bottom")}
    </section>
  `;
}

function renderMetricCards() {
  const m = data.metrics;
  const cards = [
    ["在职人数", m.active.toLocaleString(), "当前筛选范围", "active", false],
    ["应打卡人数", m.required.toLocaleString(), "剔除特殊休假", "required", false],
    ["实际打卡人数", m.actual.toLocaleString(), "有效上下班打卡", "actual", false],
    ["打卡覆盖率", `${m.coverage.toFixed(1)}%`, "实际 / 应打卡", null, false],
    ["考勤异常人数", m.abnormal.toString(), "迟到/早退/漏打卡", "abnormal", true],
    ["考勤异常率", `${m.abnormalRate.toFixed(1)}%`, "异常人数 / 应打卡", null, true],
    ["平均工时", `${m.avgHour.toFixed(2)}h`, "不含午休1h", "avgHour", false],
  ];
  if (state.filters.statusDemo === "统计中") {
    cards[2][1] = "统计中";
    cards[4][1] = "--";
  }
  return `<div class="metric-grid">${cards.map(([title, value, desc, drillKey, danger]) => `
    <button class="metric-card ${danger ? "danger" : ""} ${drillKey ? "clickable" : ""}" ${drillKey ? `data-action="openMetric" data-key="${drillKey}"` : ""}>
      <span>${title}${danger ? " ⚠" : ""}</span>
      <strong>${value}</strong>
      <em>${desc}</em>
    </button>
  `).join("")}</div>`;
}

function renderSkeletonCards(count) {
  return `<div class="metric-grid">${Array.from({ length: count }, () => `<div class="metric-card skeleton"><span></span><strong></strong><em></em></div>`).join("")}</div>`;
}

function renderStateInline(text) {
  return `<div class="inline-state">${text}</div>`;
}

function renderStateCard(title, text, retry = false) {
  return `<section class="panel state-card"><h2>${title}</h2><p>${text}</p>${retry ? `<button class="primary" data-action="filter" data-key="statusDemo" data-value="正常">重试</button>` : ""}</section>`;
}

function getAbnormalRows() {
  return [...data.abnormalEmployees]
    .map((row) => ({ ...row, employee: employeeById(row.employeeId) }))
    .filter((row) => employeeMatches(row.employee))
    .sort((a, b) => b.total - a.total);
}

function renderAbnormalEmployees(rows = getAbnormalRows()) {
  if (!rows.length) return renderStateInline("当前筛选条件下暂无异常关注员工");
  return `<div class="abnormal-list">${rows.map((row) => `
    <button class="abnormal-item" data-action="employee" data-id="${row.employeeId}">
      <span class="abnormal-info"><span class="abnormal-line"><b>${row.name}</b><em>${row.employee.id} · ${row.employee.center} / ${row.employee.department} · ${row.employee.employment}</em></span><small>迟到 <i>${row.late}</i>　早退 <i>${row.early}</i>　漏卡 <i>${row.missing}</i>　旷工 <i>${row.absenteeism}</i></small></span>
      <strong>${row.total}<small>次</small></strong>
      <span class="chevron">›</span>
    </button>
  `).join("")}</div>`;
}

function renderTrendChart() {
  const mainWidth = document.querySelector(".main")?.clientWidth || (window.innerWidth - 185);
  const w = Math.max(980, Math.floor(mainWidth - 56));
  const h = 330;
  const pad = { l: 42, r: 18, t: 18, b: 38 };
  const yMin = 7;
  const yMax = 10.8;
  const series = [
    ["manager", "负责人", "#5EA2FF", "manager"],
    ["employee", "员工", "#FF6B6B", "employee"],
    ["outsource", "人力外包", "#9B7CFF", "outsource"],
  ];
  const x = (index) => pad.l + index * ((w - pad.l - pad.r) / 11);
  const y = (value) => pad.t + (yMax - value) * ((h - pad.t - pad.b) / (yMax - yMin));
  const linePath = (key) => data.trend.map((point, index) => `${index ? "L" : "M"}${x(index)},${y(point[key])}`).join(" ");
  const areaPath = (key) => `${linePath(key)} L${x(11)},${h - pad.b} L${x(0)},${h - pad.b} Z`;
  return `
    <div class="legend">${series.map(([, name, color]) => `<span><i style="background:${color}"></i>${name}</span>`).join("")}</div>
    <div class="chart-wrap">
      <svg class="line-chart" viewBox="0 0 ${w} ${h}" role="img" aria-label="月平均工时趋势">
        <defs>
          ${series.map(([key, , color]) => `<linearGradient id="area-${key}" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="${color}" stop-opacity=".22"/><stop offset="1" stop-color="${color}" stop-opacity=".02"/></linearGradient>`).join("")}
        </defs>
        ${[7, 8, 9, 10].map((tick) => `<line x1="${pad.l}" y1="${y(tick)}" x2="${w - pad.r}" y2="${y(tick)}" class="grid-line"/><text x="18" y="${y(tick) + 4}" class="axis-text">${tick}h</text>`).join("")}
        ${data.trend.map((point, index) => `<text x="${x(index)}" y="${h - 12}" text-anchor="middle" class="axis-text">${point.month}</text>`).join("")}
        ${series.map(([key, name, color]) => `
          <path d="${areaPath(key)}" fill="url(#area-${key})"></path>
          <path d="${linePath(key)}" fill="none" stroke="${color}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"></path>
          ${data.trend.map((point, index) => `<circle class="chart-node" cx="${x(index)}" cy="${y(point[key])}" r="5" fill="#fff" stroke="${color}" stroke-width="3" data-action="chartNode" data-key="${key}" data-name="${name}" data-month="${point.month}" data-value="${point[key]}" data-mom="${point[`${key}Mom`]}"></circle>`).join("")}
        `).join("")}
      </svg>
      <div class="chart-tooltip" id="chartTooltip"></div>
    </div>
  `;
}

function renderTrendTable() {
  const groups = [
    ["员工", "employee", "employeeMom"],
    ["负责人", "manager", "managerMom"],
    ["人力外包", "outsource", "outsourceMom"],
  ];
  return `
    <table class="data-table trend-detail">
      <thead>
        <tr><th rowspan="2" class="sticky-left">考勤周期</th>${groups.map(([name]) => `<th colspan="3">${name}</th>`).join("")}</tr>
        <tr>${groups.map(() => `<th>月平均工时</th><th>同比上一年</th><th>环比上个月</th>`).join("")}</tr>
      </thead>
      <tbody>
        ${data.trend.map((row, index) => `<tr>
          <td class="sticky-left">${row.month}</td>
          ${groups.map(([, key, momKey]) => `<td>${index > 8 ? "--" : row[key]}</td><td class="muted">--</td><td>${index > 8 ? "--" : trendText(row[momKey])}</td>`).join("")}
        </tr>`).join("")}
        <tr class="summary-row"><td class="sticky-left">月均</td>${groups.map(([, key]) => `<td>${average(data.trend.slice(0, 9).map((item) => item[key])).toFixed(2)}</td><td>--</td><td>--</td>`).join("")}</tr>
      </tbody>
    </table>
  `;
}

function average(nums) {
  return nums.reduce((sum, num) => sum + num, 0) / nums.length;
}

function renderRanking(type, modeOverride = null) {
  const isDepartment = type === "department";
  const mode = modeOverride || state.rankMode[type];
  const rows = (isDepartment
    ? (mode === "top" ? data.departmentRankTop : data.departmentRankBottom)
    : (mode === "top" ? data.managerRankTop : data.managerRankBottom))
    .filter((row) => rowMatches(row));
  const modeName = mode === "top" ? "前10名" : "后10名";
  return `
    <section class="panel ranking-card">
      <div class="section-head">
        <div>
          <h2>${isDepartment ? "部门平均工时排名" : "负责人平均工时排名"} · <span class="rank-title-emphasis">${modeName}</span></h2>
          <p>${isDepartment ? "点击部门同步筛选" : "点击负责人打开员工明细"}</p>
        </div>
        <div class="section-actions">
          <label class="date-control">考勤月
            <select data-action="filter" data-key="rankMonth">
              ${data.months.map((month) => option(month, state.filters.rankMonth, month)).join("")}
            </select>
          </label>
        </div>
      </div>
      <div class="ranking-table-wrap"><table class="data-table compact-table">
        <thead><tr>${isDepartment ? "<th>排名</th><th>部门</th><th>部门人数</th><th>负责人</th><th>HRBP</th><th>平均工时</th><th>上个月工时</th><th>上月排名</th>" : "<th>排名</th><th>姓名</th><th>职级</th><th>所属部门</th><th>HRBP</th><th>平均工时</th><th>上个月工时</th><th>上月排名</th>"}</tr></thead>
        <tbody>${rows.map((row) => `<tr>
          <td>${row.rank}</td>
          ${isDepartment ? `<td><button class="link" data-action="departmentFilter" data-department="${row.department}">${row.department}</button></td><td>${row.count}</td><td><button class="link" data-action="managerDrawer">${row.manager}</button></td><td>${row.hrbp}</td>` : `<td><button class="link" data-action="employee" data-id="${row.employeeId}">${row.name}</button></td><td>${row.level}</td><td>${row.department}</td><td>${row.hrbp}</td>`}
          <td class="strong-cell">${row.avgHour}h</td><td>${row.lastHour}h</td><td>${row.lastRank}</td>
        </tr>`).join("")}</tbody>
      </table></div>
      ${rows.length ? "" : renderStateInline("当前筛选条件下暂无排名数据")}
    </section>
  `;
}

function renderReport(scope) {
  state.reportScope = scope;
  const scopeName = scope === "formal" ? "正式" : "人力外包";
  if (state.filters.statusDemo === "无权限") return renderStateCard("无权限", `当前角色未配置考勤报表（${scopeName}）查看权限。`);
  if (state.filters.statusDemo === "数据失败") return renderStateCard("数据失败", "考勤系统报表数据生成失败，请稍后重试或联系管理员。", true);
  return `
    <section class="report-toolbar">
      <div class="sub-tabs">
        ${[
          ["department", "部门考勤报表"],
          ["manager", "负责人考勤报表"],
          ["employee", "员工考勤报表"],
          ["outing", "外出数据报表"],
        ].map(([key, label]) => `<button class="${state.reportType === key ? "active" : ""}" data-action="reportType" data-type="${key}">${label}</button>`).join("")}
      </div>
      <div class="month-picker">
        <div class="month-multiselect">
          <button type="button" class="month-select-trigger" data-action="toggleMonthDropdown"><span>考勤月</span><strong>${state.filters.months.map((month) => data.monthLabels[month]).join("、") || "请选择"}</strong></button>
          ${state.monthDropdownOpen ? `<div class="month-select-menu">${data.months.map((month) => `<label><input type="checkbox" data-action="monthToggle" value="${month}" ${state.filters.months.includes(month) ? "checked" : ""}/> ${data.monthLabels[month]}</label>`).join("")}</div>` : ""}
        </div>
        <button class="report-export" data-action="export">导出</button>
      </div>
    </section>
    <section class="panel report-panel">
      ${state.filters.statusDemo === "loading" ? `<div class="table-loading">数据加载中...</div>` : state.filters.statusDemo === "empty" ? renderStateInline("当前筛选条件下暂无报表数据") : state.filters.statusDemo === "统计中" ? renderStateInline("当前考勤月数据统计中，生成完成后展示报表") : renderReportTable(scope, state.reportType)}
    </section>
  `;
}

function reportTitle(type) {
  return { department: "部门考勤报表", manager: "负责人考勤报表", employee: "员工考勤报表", outing: "外出数据报表" }[type];
}

function renderReportTable(scope, type) {
  const months = state.filters.months.length ? state.filters.months : data.months;
  let rows;
  if (type === "department") rows = scope === "formal" ? data.formalReportRows : data.outsourceReportRows;
  if (type === "manager" || type === "employee") rows = scope === "formal" ? data.formalPeopleRows : data.outsourcePeopleRows;
  if (type === "outing") rows = scope === "formal" ? data.formalOutingRows : data.outsourceOutingRows;
  rows = rows.filter(rowMatches);
  if (!rows.length) return renderStateInline("当前筛选条件下暂无报表数据");
  return `<div class="report-scroll"><table class="data-table report-table">${renderReportHead(type, months, rows)}${renderReportBody(type, rows, months)}</table></div>`;
}

function renderReportHead(type, months, rows = []) {
  const fixed = type === "department"
    ? ["事业部", "中心/工作室", "部门", "负责人", "HRBP"]
    : type === "outing"
      ? ["工作室/中心", "部门", "负责人", "HRBP", "总人数"]
      : ["工号", "姓名", "工作室/中心", "部门", "岗位子科目", "入司时间", "专业职级", "HRBP"];
  const monthCols = {
    department: ["部门总人数", "部门平均工时", "部门同上月环比", "部门排名", "部门平均人次", "异常同上月环比", "异常排名", "备注"],
    manager: ["个人月平均工时", "同上月环比", "负责人排名", "个人异常次数", "同上月环比", "负责人排名"],
    employee: ["个人月平均工时", "同上月环比", "个人异常次数", "同上月环比"],
    outing: ["申请人数", "申请天数", "平均人天", "部门排名"],
  }[type];
  const groups = {
    department: [["平均工时", 4], ["异常数据", 4]],
    manager: [["平均工时", 3], ["异常数据", 3]],
    employee: [["平均工时", 2], ["异常数据", 2]],
  }[type];
  if (!groups) {
    return `<thead><tr>${fixed.map((h, i) => `<th rowspan="2" class="sticky-col col-${i}">${h}</th>`).join("")}${months.map((m) => `<th colspan="${monthCols.length}" class="month-separator">${data.monthLabels[m]}</th>`).join("")}</tr><tr>${months.map(() => monthCols.map((h, index) => `<th class="${index === 0 ? "month-separator" : ""}">${h}</th>`).join("")).join("")}</tr></thead>`;
  }
  return `<thead><tr>${fixed.map((h, i) => `<th rowspan="3" class="sticky-col col-${i}">${h}</th>`).join("")}${months.map((m) => `<th colspan="${monthCols.length}" class="month-separator">${data.monthLabels[m]}</th>`).join("")}</tr><tr>${months.map((month) => groups.map(([label, span], index) => `<th colspan="${span}" class="report-subgroup ${index ? "group-separator" : "month-separator"}">${reportGroupLabel(type, index, rows[0]?.months?.[month], label)}</th>`).join("")).join("")}</tr><tr>${months.map(() => monthCols.map((h, index) => `<th class="${index === 0 ? "month-separator" : ""} ${index === groups[0][1] ? "group-separator" : ""}">${h}</th>`).join("")).join("")}</tr></thead>`;
}

function reportGroupLabel(type, groupIndex, monthData, fallback) {
  if (!monthData) return fallback;
  if (groupIndex === 0) {
    const label = type === "department" ? "公司平均工时" : type === "manager" ? "负责人群体平均工时" : "公司员工平均工时";
    const value = type === "department" ? monthData.companyHour : monthData.groupHour;
    return `${label} ${value}h`;
  }
  const label = type === "department" ? "公司异常均值" : type === "manager" ? "负责人异常均值" : "公司员工异常均值";
  const value = type === "department" ? monthData.companyAbnormal : monthData.groupAbnormal;
  return `${label} ${value}`;
}

function renderReportBody(type, rows, months) {
  return `<tbody>${rows.map((row) => {
    const fixed = type === "department"
      ? [row.division, row.center, `<button class="link" data-action="departmentFilter" data-department="${row.department}">${row.department}</button>`, row.manager, row.hrbp]
      : type === "outing"
        ? [row.center, `<button class="link" data-action="departmentFilter" data-department="${row.department}">${row.department}</button>`, row.manager, row.hrbp, row.count]
        : [row.id, `<button class="link" data-action="employee" data-id="${row.id}">${row.name}</button>`, row.center, row.department, row.position, row.joinedAt, row.level, row.hrbp];
    return `<tr>${fixed.map((cell, i) => `<td class="sticky-col col-${i}">${cell}</td>`).join("")}${months.map((month) => renderMonthCells(type, row.months[month])).join("")}</tr>`;
  }).join("")}</tbody>`;
}

function renderMonthCells(type, m) {
  if (type === "department") {
    return `<td class="month-separator">${m.count || "--"}</td><td class="strong-cell">${m.avgHour}h</td><td>${trendText(m.hourMom)}</td><td>${m.rank}</td><td class="group-separator danger-text">${m.abnormalAvg}</td><td>${trendText(m.abnormalMom)}</td><td>${m.abnormalRank}</td><td class="muted editable">${m.remark}</td>`;
  }
  if (type === "outing") {
    return `<td class="month-separator"><button class="link" data-action="openOuting">${m.applicantCount}</button></td><td>${m.days}</td><td class="strong-cell">${m.avgDays}</td><td>${m.rank}</td>`;
  }
  if (type === "employee") {
    return `<td class="month-separator strong-cell">${m.avgHour}h</td><td>${trendText(m.hourMom)}</td><td class="group-separator danger-text">${m.abnormalCount}</td><td>${trendText(m.abnormalMom)}</td>`;
  }
  return `<td class="month-separator strong-cell">${m.avgHour}h</td><td>${trendText(m.hourMom)}</td><td>${m.rank}</td><td class="group-separator danger-text">${m.abnormalCount}</td><td>${trendText(m.abnormalMom)}</td><td>${m.abnormalRank}</td>`;
}

function buildTrendRows(key, month, value, mom) {
  const scope = key === "outsource" ? "outsourcing" : key === "employee" ? "formal" : null;
  return filteredEmployees(scope).slice(0, 8).map((employee, index) => ({
    ...employee,
    month,
    avgHour: (Number(value) + (index - 2) * 0.08).toFixed(2),
    yoy: "--",
    mom,
    abnormalCount: index % 4,
    late: index % 3,
    early: index % 2,
    missing: index % 2 ? 1 : 0,
    absenteeism: 0,
    leaveDays: index % 3 === 0 ? "0.5" : "0",
  }));
}

function renderDrawer() {
  const { title, rows, kind } = state.drawer;
  const cleanTitle = title.replace(/[⚠△▲]/g, "").replace(/\s+明细$/, "明细").trim();
  const header = kind === "trend"
    ? "<th>工号</th><th>姓名</th><th>考勤月份</th><th>用工性质</th><th>平均工时</th><th>同比</th><th>环比</th><th>异常次数</th><th>迟到</th><th>早退</th><th>漏打卡</th><th>旷工</th><th>请假天数</th>"
    : kind === "outing"
      ? "<th>工号</th><th>姓名</th><th>中心/部门</th><th>负责人</th><th>HRBP</th><th>申请天数</th><th>外出原因</th><th>关联流程</th>"
      : "<th>工号</th><th>姓名</th><th>中心/部门</th><th>负责人</th><th>HRBP</th><th>岗位子科目</th><th>专业职级</th><th>用工性质</th><th>打卡日期</th><th>上班打卡</th><th>下班打卡</th><th>打卡结果</th><th>工作时长</th><th>备注</th>";
  const body = rows.map((row) => {
    if (kind === "trend") {
      return `<tr><td>${row.id}</td><td><button class="link" data-action="employee" data-id="${row.id}">${row.name}</button></td><td>${row.month}</td><td>${row.employment}</td><td class="strong-cell">${row.avgHour}h</td><td>${row.yoy}</td><td>${trendText(Number(row.mom))}</td><td class="danger-text">${row.abnormalCount}</td><td>${row.late}</td><td>${row.early}</td><td>${row.missing}</td><td>${row.absenteeism}</td><td>${row.leaveDays}</td></tr>`;
    }
    if (kind === "outing") {
      return `<tr><td>${row.id}</td><td><button class="link" data-action="employee" data-id="${row.id}">${row.name}</button></td><td>${row.center} / ${row.department}</td><td>${row.manager}</td><td>${row.hrbp}</td><td>${row.leaveDays || "1"}</td><td>${row.remark || "项目外出支持"}</td><td>外出审批</td></tr>`;
    }
    return `<tr><td>${row.id}</td><td><button class="link" data-action="employee" data-id="${row.id}">${row.name}</button></td><td>${row.center} / ${row.department}</td><td>${row.manager}</td><td>${row.hrbp}</td><td>${row.position}</td><td>${row.level}</td><td>${row.employment}</td><td>${row.date}</td><td>${row.clockIn}</td><td>${row.clockOut}</td><td>${statusTag(row.result)}</td><td>${row.workHour}</td><td>${row.remark}</td></tr>`;
  }).join("");
  return `
    <div class="drawer-mask" data-action="closeDrawer"></div>
    <aside class="bottom-drawer">
      <div class="drawer-head">
        <div><h2>${cleanTitle}</h2></div>
        <div><button class="drawer-export" data-action="export">导出</button><button class="icon-btn" data-action="closeDrawer">×</button></div>
      </div>
      <div class="drawer-table-wrap">
        <table class="data-table">
          <thead><tr>${header}</tr></thead>
          <tbody>${body || `<tr><td colspan="14">${renderStateInline("当前筛选条件下暂无明细数据")}</td></tr>`}</tbody>
        </table>
      </div>
      <div class="drawer-pagination">
        <span>共 ${rows.length} 条</span>
        <label>每页
          <select>
            ${[10, 20, 30, 50, 100].map((size) => `<option ${size === 10 ? "selected" : ""}>${size}</option>`).join("")}
          </select>
          条
        </label>
        <button disabled>上一页</button>
        <strong>1</strong>
        <button disabled>下一页</button>
      </div>
    </aside>
  `;
}

function statusTag(status) {
  const cls = status === "正常" ? "success" : status === "休息日" ? "neutral" : "danger";
  return `<span class="status-tag ${cls}">${status}</span>`;
}

function renderEmployeePage(id = "YK044298") {
  const employee = employeeById(id);
  const records = getFilteredRecords(id);
  const summaryRecords = getFilteredRecords(id, { ignoreQuick: true });
  const summaryCards = [
    ["平均工时", "10.2h", ""],
    ["考勤异常次数", `${summaryRecords.filter((r) => r.abnormal !== "--").length}次`, "异常"],
    ["请假天数", "0.5天", "请假"],
    ["外出天数", "0天", "外出"],
    ["加班时长", "12.5h", ""],
  ];
  const rowsHtml = records.length
    ? records.map((row) => `<tr><td>${row.date}</td><td>${row.dateType}</td><td class="${row.result === "迟到" ? "danger-text" : ""}">${row.clockIn}</td><td>${row.clockOut}</td><td class="strong-cell">${row.workHour}</td><td>${statusTag(row.result)}</td><td>${row.abnormal}</td><td>${row.remark}</td></tr>`).join("")
    : `<tr><td colspan="8" class="empty-table-cell">暂无考勤记录</td></tr>`;
  return `
    <div class="employee-page">
      <section class="employee-head">
        <div class="avatar-large">${employee.avatar}</div>
        <div class="employee-head-info">
          <div class="employee-title-row"><h1>${employee.name}</h1><span class="status-tag success">在职</span></div>
          <div class="employee-meta-row"><span>${employee.employment}</span><i></i><span>${employee.level}</span><i></i><span>${employee.center} - ${employee.department}</span></div>
        </div>
      </section>
      <nav class="detail-tabs">
        ${["基础信息", "合同记录", "异动记录", "历史绩效", "考勤记录", "奖惩记录", "盘点记录", "回流记录"].map((tab) => `<button class="${tab === "考勤记录" ? "active" : ""}">${tab}</button>`).join("")}
      </nav>
      <section class="panel employee-filter">
        <div class="employee-filter-fields">
          <label class="employee-control employee-control-month"><span>考勤月</span><select data-action="employeeFilter" data-key="month">${option("202606", state.employeeFilter.month)}${option("202605", state.employeeFilter.month)}</select></label>
          <label class="employee-control employee-control-range"><span>日期范围</span><span class="date-range-control"><input data-action="employeeFilter" data-key="start" value="${state.employeeFilter.start}" /><em>-</em><input data-action="employeeFilter" data-key="end" value="${state.employeeFilter.end}" /></span></label>
          <label class="employee-control employee-control-abnormal"><span>异常类型</span><select data-action="employeeFilter" data-key="abnormalType">${["全部", "迟到", "漏打卡", "旷工"].map((item) => option(item, state.employeeFilter.abnormalType)).join("")}</select></label>
          <label class="employee-control employee-control-scope"><span>统计口径</span><select data-action="employeeFilter" data-key="statScope">${["全口径", "标准口径"].map((item) => option(item, state.employeeFilter.statScope)).join("")}</select></label>
        </div>
        <div class="employee-filter-actions">
          <button class="employee-clear-btn" data-action="employeeReset"><span class="clear-icon" aria-hidden="true"></span><span>清空</span></button>
        </div>
      </section>
      <section class="employee-summary">
        ${summaryCards.map(([label, value, quickType]) => quickType ? `<button type="button" class="summary-card ${state.employeeFilter.quickType === quickType ? "active" : ""}" onclick="window.applyEmployeeSummaryFilter('${quickType}')"><span>${label}</span><strong>${value}</strong></button>` : `<div class="summary-card"><span>${label}</span><strong>${value}</strong></div>`).join("")}
      </section>
      <section class="panel">
        <div class="section-head employee-table-head"><div><h2>考勤明细</h2></div></div>
        <table class="data-table employee-table">
          <thead><tr><th>日期</th><th>日期类型</th><th>上班打卡</th><th>下班打卡</th><th>工作时长 <span class="info-tip" data-tip="工作时长计算逻辑：（下班卡 - 上班卡） - 1h；点击异常状态可查看说明。">?</span></th><th>打卡结果</th><th>异常类型</th><th>备注</th></tr></thead>
          <tbody>${rowsHtml}</tbody>
        </table>
        <div class="table-pagination">
          <span>共 ${records.length} 条</span>
          <span>30 条/页</span>
          <button disabled>上一页</button>
          <strong>1</strong>
          <button disabled>下一页</button>
        </div>
      </section>
    </div>
  `;
}

function getFilteredRecords(id, options = {}) {
  let records = data.attendanceRecords[id] || data.attendanceRecords.YK044298;
  if (state.employeeFilter.abnormalType && state.employeeFilter.abnormalType !== "全部") {
    records = records.filter((record) => record.abnormal === state.employeeFilter.abnormalType);
  }
  if (!options.ignoreQuick && state.employeeFilter.quickType && state.employeeFilter.quickType !== "全部") {
    const quickType = state.employeeFilter.quickType;
    if (quickType === "异常") records = records.filter((record) => record.abnormal !== "--");
    if (quickType === "请假") records = records.filter((record) => record.abnormal === "请假" || record.result === "请假");
    if (quickType === "外出") records = records.filter((record) => record.abnormal === "外出" || record.result === "外出");
  }
  return records;
}

function applyEmployeeSummaryFilter(nextType) {
  state.employeeFilter.quickType = state.employeeFilter.quickType === nextType ? "全部" : nextType;
  render();
}

window.applyEmployeeSummaryFilter = applyEmployeeSummaryFilter;

function render() {
  const route = getRoute();
  let content;
  if (route.startsWith("#/employee/")) {
    const id = route.split("/")[2] || "YK044298";
    content = renderEmployeePage(id);
  } else {
    content = renderAttendanceDashboard();
  }
  $app.innerHTML = renderShell(content);
}

function handleClick(event) {
  const target = event.target.closest("[data-action]");
  if (!target) return;
  const action = target.dataset.action;
  if (action === "navAttendance") {
    state.mainTab = "overview";
    state.drawer = null;
    setRoute("#/attendance/overview");
    render();
  }
  if (action === "navEmployee") {
    state.drawer = null;
    setRoute("#/employee/YK044298/attendance");
    render();
  }
  if (action === "toggleSidebar") {
    state.sidebarCollapsed = !state.sidebarCollapsed;
    render();
  }
  if (action === "toggleDepartmentPanel") {
    state.departmentPanelCollapsed = !state.departmentPanelCollapsed;
    render();
  }
  if (action === "departmentPanelFilter") {
    state.filters.managementDepartment = target.dataset.center || "全部";
    state.filters.localDepartment = target.dataset.department || "";
    toast(state.filters.localDepartment ? `已筛选部门：${state.filters.localDepartment}` : `已筛选管理部门：${state.filters.managementDepartment}`);
    render();
  }
  if (action === "mainTab") {
    state.mainTab = target.dataset.tab;
    state.reportScope = state.mainTab === "reportOutsource" ? "outsourcing" : "formal";
    render();
  }
  if (action === "clearFilters") {
    state.filters = { ...state.filters, managementDepartment: "全部", keyword: "", employment: "全部", level: "全部", position: "全部", location: "全部", statScope: "标准口径", abnormalMonth: "202606", rankMonth: "202606", localDepartment: "" };
    render();
  }
  if (action === "openMetric" && ensureActionAllowed("查看下钻明细")) openDrawer(`${target.innerText.split("\n")[0]}明细`);
  if (action === "chartNode" && ensureActionAllowed("查看月度工时明细")) openDrawer(`${target.dataset.month} ${target.dataset.name}月度工时明细`, buildTrendRows(target.dataset.key, target.dataset.month, target.dataset.value, target.dataset.mom), `平均工时 ${target.dataset.value}h，环比 ${target.dataset.mom}%`, "trend");
  if (action === "employee") {
    if (!ensureActionAllowed("查看员工考勤记录")) return;
    state.drawer = null;
    setRoute(`#/employee/${target.dataset.id}/attendance`);
  }
  if (action === "closeDrawer") closeDrawer();
  if (action === "rankMode") {
    state.rankMode[target.dataset.type] = target.dataset.mode;
    render();
  }
  if (action === "departmentFilter") {
    state.filters.localDepartment = target.dataset.department;
    toast(`已追加部门筛选：${target.dataset.department}`);
    render();
  }
  if (action === "removeLocalFilter") {
    state.filters.localDepartment = "";
    render();
  }
  if (action === "managerDrawer" && ensureActionAllowed("查看负责人关联员工明细")) openDrawer("负责人关联员工明细", filteredDrawerRows().slice(0, 5));
  if (action === "reportType") {
    state.reportType = target.dataset.type;
    state.monthDropdownOpen = false;
    render();
  }
  if (action === "toggleMonthDropdown") {
    state.monthDropdownOpen = !state.monthDropdownOpen;
    render();
  }
  if (action === "export" && ensureActionAllowed("导出考勤数据")) toast("已模拟导出，真实环境将生成 Excel 文件");
  if (action === "simulateLoading") updateFilter("statusDemo", "loading");
  if (action === "simulateEmpty") updateFilter("statusDemo", "empty");
  if (action === "openOuting" && ensureActionAllowed("查看外出申请明细")) openDrawer("外出申请明细", filteredDrawerRows().slice(2, 7), "外出数据仅统计已审批通过的外出流程，不含出差流程。", "outing");
  if (action === "employeeReset") {
    state.employeeFilter = { month: "202606", start: "2026/05/16", end: "2026/06/15", abnormalType: "全部", statScope: "全口径", quickType: "全部" };
    render();
  }
  if (action === "employeeQuery") toast("已按考勤记录筛选条件刷新");
  if (action === "summaryFilter") {
    applyEmployeeSummaryFilter(target.dataset.filter);
  }
  if (action === "filter" && target.dataset.value) updateFilter(target.dataset.key, target.dataset.value);
}

function handleInput(event) {
  const target = event.target;
  if (target.dataset.action === "filter") updateFilter(target.dataset.key, target.value);
  if (target.dataset.action === "employeeFilter") {
    state.employeeFilter[target.dataset.key] = target.value;
    render();
  }
  if (target.dataset.action === "monthToggle") {
    const month = target.value;
    state.filters.months = target.checked ? [...new Set([...state.filters.months, month])] : state.filters.months.filter((item) => item !== month);
    state.monthDropdownOpen = true;
    render();
  }
}

function handleChartHover(event) {
  const node = event.target.closest(".chart-node");
  const tooltip = document.querySelector("#chartTooltip");
  if (!tooltip) return;
  if (!node) {
    tooltip.classList.remove("show");
    return;
  }
  tooltip.innerHTML = `<b>${node.dataset.month} ${node.dataset.name}</b><span>平均工时：${node.dataset.value}h</span><span>同比：--</span><span>环比：${trendText(Number(node.dataset.mom))}</span>`;
  tooltip.style.left = `${event.offsetX + 16}px`;
  tooltip.style.top = `${event.offsetY - 16}px`;
  tooltip.classList.add("show");
}

document.addEventListener("click", handleClick);
document.addEventListener("input", handleInput);
document.addEventListener("change", handleInput);
document.addEventListener("mousemove", handleChartHover);
window.addEventListener("hashchange", render);
window.addEventListener("resize", () => {
  window.clearTimeout(render._resizeTimer);
  render._resizeTimer = window.setTimeout(render, 120);
});

if (!window.location.hash) window.location.hash = "#/attendance/overview";
render();
